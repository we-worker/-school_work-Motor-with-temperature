#ifndef __control_H
#define __control_H

#define pwm_LIMIT 1000


void Set_fan_speed(unsigned int val);




#endif
